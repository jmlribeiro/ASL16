This folder contains middleware logs pertaining to the experiment run in section 2 of Milestone 2 with a set logging ratio of 100.

Each file is of the form log_{nr. servers}_{rep. factor}_{repetition}.log