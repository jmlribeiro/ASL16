This folder contains memaslap logs pertaining to the experiment run in section 2 of Milestone 2 with a set logging ratio of 100 (to confirm no impact).

Each file is of the form log_{machine}_{nr. servers}_{rep. factor}_{repetition}_105s.