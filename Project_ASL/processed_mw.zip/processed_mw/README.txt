This folder contains the result of processing the middleware logs pertaining to the experiment run in section 1 of Milestone 2.

rev_t{queue OR server OR total}_{50 OR 90 OR 99}p_{nr. threads}.csv corresponds to a list containing, for each number of clients, the 50th/90th/99th percentiles of T_queue/T_server/T_total over the 4 repetitions for a given number of threads.

rev_t{queue OR server OR total}_avg_{nr. threads}.csv corresponds to a list containing, for each number of clients, the average of T_queue/T_server/T_total over the 4 repetitions for a given number of threads.

rev_t{queue OR server OR total}_std_{nr. threads}.csv corresponds to a list containing, for each number of clients, the standard deviation of T_queue/T_server/T_total over the 4 repetitions for a given number of threads.