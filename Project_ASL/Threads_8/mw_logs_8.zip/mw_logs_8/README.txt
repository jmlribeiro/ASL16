This folder contains middleware logs pertaining to the experiment run in section 1 of Milestone 2.

Each file is of the form log_{nr. threads}_{clients per machine}_{repetition}.log