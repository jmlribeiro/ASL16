This folder contains memaslap logs pertaining to the experiment run in section 1 of Milestone 2.

Each file is of the form log_{machine}_{nr. threads}_{clients per machine}_{repetition}.log