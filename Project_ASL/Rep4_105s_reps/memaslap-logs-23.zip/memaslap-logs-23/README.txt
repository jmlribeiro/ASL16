This folder contains memaslap logs pertaining to the experiment in section 3 of Milestone 2.

Each file is of the form log_{machine}_{nr. servers}_{rep. factor}_{repetition}_{write prop.}.