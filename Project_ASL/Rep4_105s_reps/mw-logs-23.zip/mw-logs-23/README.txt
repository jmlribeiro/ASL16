This folder contains middleware logs pertaining to the experiment in section 3 of Milestone 2.

Each file is of the form log_{nr. servers}_{rep. factor}_{repetition}_{write prop.}.log