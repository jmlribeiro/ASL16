This folder contains two folders containing logs for the busy threads benchmark of Section 2 of Milestone 3.

folder ‘memaslap’ contains the memaslap logs from the experiments. They are of the form log_{client}_{nr. servers}_{rep. factor}_{repetition}_{write prop.}

folder ‘mw’ contains the middleware logs. They are of the form log_{nr. servers}_{rep. factor}_{repetition}_{write prop.}.log.