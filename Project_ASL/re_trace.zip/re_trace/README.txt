This folder contains the raw memaslap and middleware logs pertaining to the stability trace re-run for Milestone 2.

rev_trace_{client} is the memaslap log of a given client.

rev_trace_mw is the middleware log.

trace_avg_std.csv contains the processed average response time and standard deviation from the memaslap logs.

trace_avg.csv contains the processed average response time.

trace_tps.csv contains the processed throughput.